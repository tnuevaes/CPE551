# Author: Your name
# Date: Today's date
# Description: Given a duration of time, this program computes 
# the velocity, average velocity, and displacement of an object.

# Useful values:
acceleration = 5.25
initialVelocity = 8.25

# Initialize the radius:
time = 10.0

# Calculate the properties of the object:

  (replace this line with your code)

# Print the results:

  (replace this line with your code)
